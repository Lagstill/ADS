/*************************************************************
            ADVANCE DATA STRUCTURE LAB
                    18XD34
            PSG COLLEGE OF TECHNOLOGY
                     AMCS
            PROBLEM_SHEET_2_[2]
                   19PD05
30/10/2020      III SEMESTER
****************************************************************/
#include<iostream>
#include<fstream>
#include<sstream>

using namespace std;

struct Node
{
    int data;
    int value_field;
    Node* left;
    Node* right;
    Node *parent;
};

Node* root=NULL;

class Splay
{
public:
    void r_rotate(Node*);
    void l_rotate(Node*);
    void splay(Node* );
    int search(int);
    void insert(int);
    void postorder(Node*);

};

int main()
{
    Splay sp;
    ifstream fp;
    string ch;
    int dat;
    int var;
    int var1;
    int prev=0;
    string filename="enroll.txt";
    fp.open(filename.c_str());
    while(true)
    {
        cout<<"\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n";
        cout<<"ENTER ONE OF THE OPTIONS BELOW :\n\n";
        cout<<" 1.INSERT KEY/DATA INTO SPLAY TREE\n";
        cout<<" 2.FIND A KEY/DATA IN THE SPLAY TREE\n";
        cout<<" 3.DISPLAY THE SPLAY TREE\n";
        cout<<" 4.EXIT\n";
        cout<<"\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n";
        cin>>var;
        switch(var)
        {
        case 1:
            if(!fp)
            {
                cout<<"\nNo such file exists"<<endl;
            }
            else
            {
                cout<<"\nLODING THE DATA INTO THE SPLAY TREE....\n";
                while(fp>>ch)
                {
                    if(ch=="0000000")
                        break;
                    else
                    {
                        stringstream con(ch);
                        con>>dat;
                        sp.insert(dat);
                    }
                }
            }
            fp.close();
            break;
        case 2:

            cout<<"\nENTER THE VALUE TO BE FOUND : \t";
            cin>>var1;
            dat=sp.search(var1);
            if(!dat)
            {
                cout<<"\nSERACH UNSUCCESSFULL !!! \nTHE PREVIOUS SEARCH NODE HAS BEEN SPLAYED\n ";
            }
            else
            {
                cout<<"\nSEARCH SUCCESSFUL!!!\nTHE SEARCH NODE HAS BEEN SPLAYED\n ";
            }
            break;
        case 3:
            cout<<"\nPOSTORDER TRANVERSAL OF THE SPLAY TREE\n";
            cout<<"DATA VALUES"<<" -> "<<"VLAUE FIELD"<<endl;
            sp.postorder(root);
            break;
        case 4:
            cout<<"\nEXITING.....\n";
            exit(1);
        default:
            cout<<"\n WRONG CHOICE....";
            break;
        }
    }
    return 0;
}

void Splay::postorder(Node* root)
{
    if(root!=NULL)
    {
        postorder(root->left);
        postorder(root->right);
        cout<<root->data<<"     ->      "<<root->value_field<<endl;

    }
}
void Splay::r_rotate(Node* par)
{
    Node* p_parent=par->parent;
    Node* child   =par->left;
    Node* g_child =child->right;

    if(p_parent!=NULL)
    {
        if(p_parent->right==par)
        {
            p_parent->right=child;
        }
        else
        {
            p_parent->left=child;
        }
    }
    if(g_child!=NULL)
    {
        g_child->parent=par;
    }
    child->parent=p_parent;
    child->right=par;
    par->parent=child;
    par->left=g_child;
}

void Splay::l_rotate(Node* par)
{
    Node* p_parent=par->parent;
    Node* child   =par->right;
    Node* g_child =child->left;

    if(p_parent!=NULL)
    {
        if(p_parent->right==par)
        {
            p_parent->right=child;
        }
        else
        {
            p_parent->left=child;
        }
    }
    if(g_child!=NULL)
    {
        g_child->parent=par;
    }
    child->parent=p_parent;
    child->left=par;
    par->parent=child;
    par->right=g_child;
}

void Splay::insert(int d)
{
    Node* temp=root;
    if(root==NULL)
    {
        root=new Node;
        root->data=d;
        root->left=NULL;
        root->right=NULL;
        root->parent=NULL;
        root->value_field=1;
        return ;
    }
    else
    {
        while(1)
        {
            if(d<temp->data)
            {
                if(temp->left!=NULL)
                    temp=temp->left;
                else
                {
                    temp->left=new Node;
                    temp->left->parent=temp;
                    temp->left->right=NULL;
                    temp->left->left=NULL;
                    temp->left->data=d;
                    temp->left->value_field=1;
                    temp=temp->left;
                    break;
                }

            }
            else if(temp->data<d)
            {
                if(temp->right!=NULL)
                    temp=temp->right;
                else
                {

                    temp->right=new Node;
                    temp->right->parent=temp;
                    temp->right->right=NULL;
                    temp->right->left=NULL;
                    temp->right->data=d;
                    temp->right->value_field=1;
                    temp=temp->right;
                    break;
                }
            }
            else
            {
                temp->value_field=1+temp->value_field;
                break;
            }
        }
    }
    splay(temp);

}

void Splay::splay(Node* temp)
{

    while(true)
    {
        Node *p=temp->parent;
        if(p==NULL)
            break;
        Node *tp=p->parent;
        if(!tp)
        {
            if(p->left==temp)
                r_rotate(p);
            else
                l_rotate(p);
            break;
        }
        if(tp->left==p)
        {
            if(p->left==temp)
            {
                r_rotate(tp);
                r_rotate(p);
            }
            else
            {
                l_rotate(p);
                r_rotate(tp);
            }
        }
        else
        {
            if(p->left==temp)
            {
                r_rotate(p);
                l_rotate(tp);
            }
            else
            {
                l_rotate(tp);
                l_rotate(p);
            }
        }

    }
    root=temp;
}

int Splay::search(int d)
{
    if(!root)
        return 0;
    Node *tem=root;
    while(tem)
    {
        if(tem->data==d)
            break;
        if(d<(tem->data))
        {
            if(tem->left)
                tem=tem->left;
            else
                break;
        }
        else
        {
            if(tem->right)
                tem=tem->right;
            else
                break;
        }
    }
    splay(tem);
    if(tem->data==d)
    {
        splay(tem);
        return tem->data;
    }
    else
        return 0;
}
