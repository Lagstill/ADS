/****************************************
        PSG COLLEGE OF TECHNOLOGY
                AMCS
            18XD56~DAA LAB
              WORSHEET-I
        19PD05~ALAGU PRAKALYA
****************************************/



#include<iostream>
#include<string>
#include<bits/stdc++.h>
#include<stdio.h>

using namespace std;


//1.
/*
int main()
{
    int arr[50];
    int temp;
    int l,r,k,counter=0;

    cout << "ENTER THE NUMBER OF ELEMENTS IN THE ARRAY : ";
    cin>>counter;
    cout<<"ENTER THE ELEMENTS IN THE ARRAY : "<<endl;
    for (int i=0;i<counter;i++)
    {
        cin>>arr[i];
    }
    cout<<"ENTER THE LEFT RANGE : ";
    cin>>l;
    cout<<"ENTER THE RIGHT RANGE : ";
    cin>>r;
    cout<<"ENTER THE K-VALUE : ";
    cin>>k;
    //with sorting
    counter=0;
    for(int i=l;i<r;i++)
	{
		for(int j=i+1;j<r;j++)
		{
			if(arr[i]>arr[j])
			{
				temp  =arr[i];
				arr[i]=arr[j];
				arr[j]=temp;

			}

		}
        counter++;
        if(counter==k)
        {
            cout<<k<<"th LARGEST ELEMENT : "<<arr[i]<<endl;
           // exit();
   }     }

    //without sorting
 /*   counter=0;
    for(int i=l;i<r;i++)
	{
		for(int j=i+1;j<r;j++)
		{
		    if(arr[i]>arr[j])
              temp=arr[i];
        }
		counter++;
		if(counter==k)
        {
            cout<<k<<"th LARGEST ELEMENT : "<<temp<<endl;
        }
	}

    return 0;

}
*/

//2.

int getPairs(int arr[], int n)
{
    // Set to store unique pairs
    set<pair<int, int>> h;
    for(int i = 0; i < (n - 1); i++)
    {
        for (int j = i + 1; j < n; j++)
        {

            // Create pair of (arr[i], arr[j])
            // and add it to the hashset
            h.insert(make_pair(arr[i], arr[j]));
        }
    }

    // Return the size of the HashSet
    return h.size();
}
int main()
{
    int counter,arr[50];

    cout << "ENTER THE NUMBER OF ELEMENTS IN THE ARRAY : ";
    cin>>counter;
    cout<<"ENTER THE ELEMENTS IN THE ARRAY : "<<endl;
    for (int i=0;i<counter;i++)
    {
        cin>>arr[i];
    }
    printf("%d", getPairs(arr, counter)) ;
    return 0;
}


//3.
/*
int getInvCount(int arr[], int n)
{
    int inv_count = 0;
    for (int i = 0; i < n - 1; i++)
        for (int j = i + 1; j < n; j++)
            if (arr[i] > arr[j])
                inv_count++;

    return inv_count;
}


int main()
{
    int counter,arr[50];

    cout << "ENTER THE NUMBER OF ELEMENTS IN THE ARRAY : ";
    cin>>counter;
    cout<<"ENTER THE ELEMENTS IN THE ARRAY : "<<endl;
    for (int i=0;i<counter;i++)
    {
        cin>>arr[i];
    }
    cout << " Number of inversions are "
         << getInvCount(arr, counter);
    return 0;
}*/

//4.
/*
void printRepeating(int arr[], int size)
{
    int i;
    cout << "The repeating elements are:" << endl;
    for (i = 0; i < size; i++) {
        if (arr[abs(arr[i])] >= 0)
            arr[abs(arr[i])] = -arr[abs(arr[i])];
        else
            cout << abs(arr[i]) << " ";
    }
}
int main()
{

     int counter,arr[50];

    cout << "ENTER THE NUMBER OF ELEMENTS IN THE ARRAY : ";
    cin>>counter;
    cout<<"ENTER THE ELEMENTS IN THE ARRAY : "<<endl;
    for (int i=0;i<counter;i++)
    {
        cin>>arr[i];
    }
    printRepeating(arr, counter);
    return 0;
}*/


//5.
/*
int countPairs(int arr[], int n,int key)
{


    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            // Increment count if condition satisfy
            if (((arr[i] * arr[i])+(arr[j]*arr[j])) == key)

              return 1;
        }
    }

    // Return count of pairs
    return 0;
}

// Driver code
int main()
{
   int counter,arr[50],key;

    cout << "ENTER THE NUMBER OF ELEMENTS IN THE ARRAY : ";
    cin>>counter;
    cout<<"ENTER THE ELEMENTS IN THE ARRAY : "<<endl;
    for (int i=0;i<counter;i++)
    {
        cin>>arr[i];
    }
    cout << "ENTER THE KEY NUMBER : ";
    cin>>key;

    if (countPairs(arr, counter,key)==1)
   {
       cout << "MATCH EXISTS";}
    else
     cout << "MATCH DOES NOT EXISTS";

    return 0;
}
*/
//6.
/*
#include<iostream>
using namespace std;
int main()
{
    int n,i,j,k,m=0;
    cout<<"\nEnter number of array elements : ";
    cin>>n;
    int a[n];
    cout<<"\nFill the array : ";
    for(i=0;i<n;i++)
        cin>>a[i];
    for(i=1;i<n;i++)
    {
        if(a[i-1]<a[i]&&a[i]>a[i+1])
        {
            cout<<"The element k is : "<<i<<endl;
            break;
        }
    }
}

*/
//8.
/*
class Time {
public:
    string largestTimeFromDigits(vector<int>& a) {
        string ans = ""; int mx = -1, h1 = -1, h2 = -1, m1 = -1, m2 = -1;

        for(int i=0; i<4; ++i) {
            if(a[i] > 2)
                continue;

            for(int j=0; j<4; ++j) {
                if(j == i)
                    continue;
                if(a[i] == 2 && a[j] > 3)
                continue;

                for(int k=0; k<4; ++k) {
                    if(k == j || k == i)
                        continue;
                    if(a[k] > 5)
                    continue;

                    for(int l=0; l<4; ++l) {
                        if(l == k || l == j || l == i)
                            continue;
                    // value of time in minutes.

                        int val = (a[l] + (a[k] * 10)) + (a[j] + (a[i] * 10)) * 60;
                        if(mx < val) {
                            mx = val;
                            h1 = a[i], h2 = a[j], m1 = a[k], m2 = a[l];
                        }

                    }
                }
            }
        }

        if(h1 == -1 || h2 == -1 || m1 == -1 || m2 == -1)
            return "wrong time predicted!!!";

        ans = to_string(h1) + to_string(h2) + ":" + to_string(m1) + to_string(m2);

        return ans;
    }
};

int main()
{
    Time inp;
    int num;
    vector<int> vect;
    cout<<"ENTER THE FOUR DIGITS : ";
    for(int i=0;i<4;i++)
    {
        cin>>num;
        vect.push_back(num);
    }
    cout<<"ANSWER: "<<inp.largestTimeFromDigits(vect);
    return 0;
}*/


//9.
/*
#include<iostream>
using namespace std;
int main()
{
    int n,i,j,k,m=0;
    cout<<"\nEnter number of array elements : ";
    cin>>n;
    int a[n];
    cout<<"\nFill the array : ";
    for(i=0;i<n;i++)
        cin>>a[i];
    for (int i = 0; i < n; i++)
    {
        while (a[i] % 2 == 0)
            a[i] /= 2;
        while (a[i] % 3 == 0)
            a[i] /= 3;
        if (a[i] != a[0])
        {
            cout<<"\nNO!!\n";
            return 0;
        }
    }
    cout<<"\nTrue!!\n";
}

*/
//10.
/*
#include <bits/stdc++.h>
using namespace std;

#define ROW 5
#define COL 5
int isSafe(int M[][COL], int row, int col,
           bool visited[][COL])
{
    return (row >= 0) && (row < ROW) && (col >= 0) && (col < COL) && (M[row][col] && !visited[row][col]);
}
void DFS(int M[][COL], int row, int col,
         bool visited[][COL])
{
    static int rowNbr[] = { -1, -1, -1, 0, 0, 1, 1, 1 };
    static int colNbr[] = { -1, 0, 1, -1, 1, -1, 0, 1 };
    visited[row][col] = true;
    for (int k = 0; k < 8; ++k)
        if (isSafe(M, row + rowNbr[k], col + colNbr[k], visited))
            DFS(M, row + rowNbr[k], col + colNbr[k], visited);
}
int countIslands(int M[][COL])
{
    bool visited[ROW][COL];
    memset(visited, 0, sizeof(visited));
    int count = 0;
    for (int i = 0; i < ROW; ++i)
        for (int j = 0; j < COL; ++j)
            if (M[i][j] && !visited[i][j])
            {
                DFS(M, i, j, visited);
                ++count;
            }

    return count;
}
int main()
{
    int M[][COL] = { { 1, 1, 0, 0, 0 },
                     { 0, 1, 0, 0, 1 },
                     { 1, 0, 0, 1, 1 },
                     { 0, 0, 0, 0, 0 },
                     { 1, 0, 1, 0, 1 } };

    cout << "Number of islands is: " << countIslands(M);

    return 0;
}
*/
