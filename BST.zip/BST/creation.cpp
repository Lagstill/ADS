#include<stdio.h>
#include<iostream>

using namespace std;

struct tree_node
{
    int data;
    tree_node *left_child,*right_child;//*parent;
};


class BST
{
    tree_node *root;
    void insert(tree_node*,int);
    bool search(int,tree_node*);
    void inorder(tree_node* );
	void preorder(tree_node* );
	void postorder(tree_node* );
public:
    BST()
	{
		root = NULL;
	}
	void insert(int );
	bool search(int key);
    void inorder();
    void preorder();
    void postorder();


};


void BST::insert(tree_node* node,int d)
{
    //tree_node *temp=node;

    if(d<node->data)
    {
        if(!(node->left_child== NULL))
        {
            cout<<"kkkkkkg";
            insert(node->left_child,d);
        }
        else
        {
            cout<<"kkkkkkg";
            node->left_child=new tree_node;
            node->data=d;
            node->left_child= NULL;
            node->right_child= NULL;
            //node->parent=temp;
            cout<<"kkkk";
        }
    }
    if (d >= node->data)
    {
        if(!(node->right_child== NULL))
        {
            insert(node->right_child,d);
        }
        else
        {
            node->right_child=new tree_node;
            node->data=d;
            node->left_child=NULL;
            node->right_child=NULL;
        }
    }

}

void BST::insert(int d)
{
    if(!(root== NULL))
    {

        insert(root,d);

    }
    else
    {

        root=new tree_node;
        root->data=d;
        root->left_child=NULL;
        root->right_child=NULL;
    }

}

bool BST::search(int d, tree_node *node)
{
	bool ans = false;

	// node is not present
  	if(node == NULL)
 		return false;

	// Node�s data is equal to value searched
    if(d == node->data)
      	return true;

	// Node�s data is greater than value searched
    else if(d < node->data)
       	ans = search(d, node->left_child);

	// Node�s data is lesser than value searched
    else
       	ans = search(d, node->right_child);

    return ans;
}
bool BST::search(int d)
{
	if(root ==  NULL)
		return false;
	else
		return  search(d, root);
}

int main()
{
BST b;
b.insert(7);
b.insert(9);


}
