/*************************************************************
            ADVANCE DATA STRUCTURE LAB
                    18XD34
            PSG COLLEGE OF TECHNOLOGY
                     AMCS
                  PROBLEM_2
                   19PD05
29/09/2020    III SEMESTER ADS_LAB
****************************************************************/
#include<iostream>
#include<stdio.h>
#include<fstream>
#include<stdlib.h>
#include<bits/stdc++.h>
#include<string.h>
using namespace std;

struct avl_node                          //creating each node in the tree
{
    string word;
    avl_node *left_child=NULL;
    avl_node *right_child=NULL;

};

struct avl_node* root=NULL;

class avlTree                           //a common class for representing the functions of the trees to be performed
{
public:                                 //application of oops
    int height(avl_node *);
    int diff(avl_node *);
    int dict_size(avl_node*);
    bool search_node(avl_node*,string);
    avl_node *rr_rotation(avl_node *);
    avl_node *ll_rotation(avl_node *);
    avl_node *lr_rotation(avl_node *);
    avl_node *rl_rotation(avl_node *);
    avl_node* balance(avl_node *);
    avl_node* insert_node(avl_node *, string );
    avl_node* minValueNode(avl_node*);
    avl_node *delete_node(avl_node *,string);
    avlTree()
    {
        root = NULL;
    }
};

int main()
{
    int i=0;
    bool dec=false;
    ifstream pt;
    ifstream fp;
    string word,temp,ch;
    int choice=1;
    int flag=0;
    avlTree avl;
    string filename="dictionary.txt";
    pt.open(filename.c_str());
    cout<<"\nWORDS IN THE DICTIONARY :"<<endl;                        //opening the .txt file with words entered into new-line and read
    if(!pt)
    {
        cout<<"No such file exists"<<endl;
    }
    else
    {
        while(pt>>ch)
        {
            cout<<ch<<"\t:\t";
            root = avl.insert_node(root,ch);      //creating an avl_tree
        }
    }
    pt.close();
    while (choice)
    {
        cout<<"\n---------------------"<<endl;
        cout<<"AVL Tree Implementation of a dictionary : "<<endl;
        cout<<"\n---------------------"<<endl;
        cout<<"1.Load Dictionary"<<endl;
        cout<<"2.Get Dictionary size"<<endl;
        cout<<"3.Insert word"<<endl;
        cout<<"4.Look-up for a word"<<endl;
        cout<<"5.Remove word"<<endl;
        cout<<"6.Exit"<<endl;
        cout<<"Enter your Choice: ";
        cin>>choice;
        if(choice!=3)
        {
            switch(choice)
            {
            case 1:
                cout<<"LOADING THE DICTIONARY INTO AN AVL TREE.....\n";
                break;
            case 2:
                if (root == NULL)
                {
                    cout<<"Tree is Empty"<<"~~hence the size is : 0"<<endl;
                    continue;
                }
                cout<<"The size of the dictionary is :  " <<avl.dict_size(root)<<endl;
                break;
            case 4:
                cout<<"ENTER THE WORD TO  BE LOOKED UP ON THE DICTIONARY :"<<endl;
                cin>>word;
                dec=avl.search_node(root,word);
                if(dec)
                {
                    cout<<"TRUE :WORD FOUND IN THE DICTIONARY"<<endl;
                }
                else
                    cout<<"FALSE : WORD NOT FOUND IN THE DICTIONARY"<<endl;
                break;
            case 5:
                cout<<"ENTER THE WORD TO BE REMOVED FROM THE DICTIONARY : "<<endl;
                cin>>word;
                root=avl.delete_node(root,word);
                cout<<endl;
                break;
            case 6:
                exit(1);
                break;
            default:
                cout<<"Wrong Choice"<<endl;
            }
        }
        else
        {
            cout<<"Enter the word to be inserted : "<<endl;
            cin>>word;
            transform(word.begin(),word.end(),word.begin(), ::tolower);
            fp.open(filename.c_str());
            if(!fp)
            {
                cout<<"No such file exists"<<endl;
            }
            else
            {
                while(fp>>ch)
                {
                    if(word==ch)
                    {

                        flag=1;
                    }
                }
            }
            fp.close();
            if(!flag)
            {
                root=avl.insert_node(root,word);
                cout<<"WORD INSERTED\n";
                flag=0;
            }
            else
            {
                cout<<"ERROR:Word already in the dictionary!"<<endl;
            }
        }
    }
    return 0;

}

int avlTree::dict_size(avl_node* root)                   //returns the total number of elements in the tree
{
    if(root==NULL)
        return 0;
    return 1 + dict_size(root->left_child) + dict_size(root->right_child);
}

bool avlTree::search_node(avl_node* temp,string word)     //searches for the given word in the tree
{
    while(temp)
    {
        if (temp->word==word)
        {
            return true;
        }
        else if (word<temp->word)                            //checking if the word is left or right child
        {
            temp=temp->left_child;
        }
        else if (word >= temp->word)
        {
            temp=temp->right_child ;
        }
    }
    return false;
}

avl_node *avlTree::insert_node(avl_node *root, string w)       //to insert a new node into the dictionary
{

    if (root == NULL)
    {
        root = new avl_node;
        root->word = w;
        root->left_child = NULL;
        root->right_child = NULL;
        return root;
    }
    else if (w< root->word)
    {
        root->left_child= insert_node(root->left_child,w);
        root = balance (root);
    }
    else if (w >= root->word)
    {
        root->right_child = insert_node(root->right_child,w);
        root = balance (root);
    }
    return root;
}

avl_node *avlTree::balance(avl_node *temp)           //most important of all it balances the avl tree after each insertion made into the dictionary
{
    int bal_factor = diff (temp);
    if (bal_factor > 1)
    {
        if (diff (temp->left_child) > 0)
            temp = ll_rotation (temp);
        else
            temp = lr_rotation (temp);
    }
    else if (bal_factor < -1)
    {
        if (diff (temp->right_child) > 0)
            temp = rl_rotation (temp);
        else
            temp = rr_rotation (temp);
    }
    return temp;
}

int avlTree::height(avl_node *temp)                     //returns the height of the node,helped in the calculation of the balance factor
{
    int h = 0;
    if (temp != NULL)
    {
        int l_height = height (temp->left_child);
        int r_height = height (temp->right_child);
        int max_height = max (l_height, r_height);
        h = max_height + 1;
    }
    return h;
}

/*
 * Height Difference
 */
int avlTree::diff(avl_node *temp)                                //the diff for an avl_tree must be 0,-1,1
{
    int l_height = height (temp->left_child);
    int r_height = height (temp->right_child);
    int b_factor= l_height - r_height;
    return b_factor;
}

/*
 * Right- Right Rotation
 */
avl_node *avlTree::rr_rotation(avl_node *n)
{
    avl_node *temp;
    temp = n->right_child;
    n->right_child= temp->left_child;
    temp->left_child= n;
    return temp;
}
/*
 * Left- Left Rotation
 */
avl_node *avlTree::ll_rotation(avl_node *n)
{
    avl_node *temp;
    temp = n->left_child;
    n->left_child = temp->right_child;
    temp->right_child = n;
    return temp;
}

/*
 * Left - Right Rotation
 */
avl_node *avlTree::lr_rotation(avl_node *n)
{
    avl_node *temp;
    temp = n->left_child;
    n->left_child = rr_rotation (temp);
    return ll_rotation (n);
}

/*
 * Right- Left Rotation
 */
avl_node *avlTree::rl_rotation(avl_node *n)
{
    avl_node *temp;
    temp = n->right_child;
    n->right_child = ll_rotation (temp);
    return rr_rotation (n);
}

avl_node* avlTree::minValueNode(avl_node* node)                       //for deletion it returns the inorder successor
{
    while(true)                                                       //which is the minimum of the left-sub-tree
    {
        if(node->left_child==NULL)
            return node;
        else
        {
            node=node->left_child;
        }
    }
}

avl_node* avlTree::delete_node(avl_node* root,string w)
{

    if(!search_node(root,w))                                          //checks if the word to be deleted is in the dictionary or not
    {
        cout<<" FALSE : WORD NOT FOUND IN THE DICTIONARY..."<<endl;
        return root;
    }
    else
    {
        if (w< root->word )
            root->left_child = delete_node(root->left_child, w);
        else if( w> root->word )
            root->right_child = delete_node(root->right_child, w);
        else
        {
            if( (root->left_child == NULL) ||(root->right_child == NULL) )
            {
                avl_node *temp = root->left_child ?root->left_child :root->right_child;
                if (temp == NULL)
                {
                    temp = root;
                    root = NULL;
                }
                else
                {
                    root->word= temp->word;
                    if(temp==root->left_child)
                        root->left_child=NULL;
                    else
                        root->right_child=NULL;
                }
            }
            else
            {
                avl_node* temp = minValueNode(root->right_child);                  //the node to be deleted is removed and replaced
                root->word= temp->word;
                root->right_child = delete_node(root->right_child,temp->word);
            }
        }
        cout<<" TRUE: WORD FOUND IN THE DICTIONARY... AND SUCCESSFULLY DELETED..."<<endl;
        if (root == NULL)
            return root;
        root = balance (root);
        return root;
    }

}
