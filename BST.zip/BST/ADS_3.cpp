/*************************************************************
            ADVANCE DATA STRUCTURE LAB
                    18XD34
            PSG COLLEGE OF TECHNOLOGY
                     AMCS
                  PROBLEM_3
                   19PD05
3/10/2020    III SEMESTER ADS_LAB
****************************************************************/

#include<stdio.h>
#include<iostream>
#include <bits/stdc++.h>

using namespace std;

struct avl_node                            //creates the node elements of the avl_tree
{
    int data;
    struct avl_node *left;
    struct avl_node *right;
};

struct avl_node* root_1=NULL;              //Two tree's root are intialised to NULL
struct avl_node* root_2=NULL;

class avlTree
{
public:
    int height(avl_node *);
    int diff(avl_node *);
    avl_node *rr_rotation(avl_node *);
    avl_node *ll_rotation(avl_node *);
    avl_node *lr_rotation(avl_node *);
    avl_node *rl_rotation(avl_node *);
    avl_node* balance(avl_node *);
    avl_node* insert(avl_node *, int );
    avl_node *Join(avl_node*,avl_node*);
    void display(avl_node *, int);
    bool check(avl_node*,avl_node*);
    avlTree()
    {
        root_1 = NULL;
        root_2=NULL;
    }
};

int main()
{
beginning:
    cout<<"\n***********************************************";
    cout<<"         REMEMBER: max(T1) > min(T1)\n";
    cout<<"***********************************************\n";
    int choice, item,a,b;
    avlTree avl;
    cout<<"ENTER THE TOTAL NUMBER OF ELEMENTS IN T1 :\t";
    cin>>a;
    for(int i=0; i<a; i++)
    {
        cout<<"\nEnter value to be inserted: ";
        cin>>item;
        root_1 = avl.insert(root_1, item);
    }
    cout<<"\nENTER THE TOTAL NUMBER OF ELEMENTS IN T1 :\t";
    cin>>b;
    for(int i=0; i<b; i++)
    {
        cout<<"\nEnter value to be inserted: ";
        cin>>item;
        root_2 = avl.insert(root_2, item);
    }
    cout<<"\n\nLOADING THE TWO AVL_TREES..."<<endl;
    if(avl.check(root_1,root_2))
    {
        cout<<"\t\tT1\t\t\n";
        avl.display(root_1,1);
        cout<<"\n\n\n"<<endl;
        cout<<"\t\tT2\t\t\n";
        avl.display(root_2,1);
        avl.Join(root_1,root_2);
        cout<<"\n\t*************************************************"<<endl;
        avl.display(root_2,1);
    }
    else
    {
        goto beginning;
    }                                                     //checks if max(T1)<min(T1)
    return 0;
}

avl_node* avlTree::Join(avl_node* root,avl_node* pt)  //forms the union of T1,T2 and stores the final tree under T2
{

    queue<avl_node*> q;  // using stl
    avl_node* temp;
    q.push(root);
    while(!q.empty())
    {
        temp=q.front();
        q.pop();
        root_2=insert(root_2,temp->data);
        if(temp->left)
            q.push(temp->left); //EnQueue
        if(temp->right)
            q.push(temp->right); //EnQueue
    }


}

bool avlTree::check(avl_node* T1,avl_node* T2)                      //checks if max(T1)<min(T1)
{
    int a,b;
    while(T2->left!=NULL)
    {
        T2=T2->left;
    }
    a=T2->data;
    while(T1->right!=NULL)
    {
        T1=T1->right;
    }
    b=T1->data;
    cout<<a<<":"<<b<<endl;
    if(a>b)
        return true;

    return false;
}
int avlTree::height(avl_node *temp)                             //it'll be as done in problem_2
{
    int h = 0;
    if (temp != NULL)
    {
        int l_height = height (temp->left);
        int r_height = height (temp->right);
        int max_height = max (l_height, r_height);
        h = max_height + 1;
    }
    return h;
}

/*
 * Height Difference
 */
int avlTree::diff(avl_node *temp)
{
    int l_height = height (temp->left);
    int r_height = height (temp->right);
    int b_factor= l_height - r_height;
    return b_factor;
}

/*
 * Right- Right Rotation
 */
avl_node *avlTree::rr_rotation(avl_node *parent)
{
    avl_node *temp;
    temp = parent->right;
    parent->right = temp->left;
    temp->left = parent;
    return temp;
}
/*
 * Left- Left Rotation
 */
avl_node *avlTree::ll_rotation(avl_node *parent)
{
    avl_node *temp;
    temp = parent->left;
    parent->left = temp->right;
    temp->right = parent;
    return temp;
}

/*
 * Left - Right Rotation
 */
avl_node *avlTree::lr_rotation(avl_node *parent)
{
    avl_node *temp;
    temp = parent->left;
    parent->left = rr_rotation (temp);
    return ll_rotation (parent);
}

/*
 * Right- Left Rotation
 */
avl_node *avlTree::rl_rotation(avl_node *parent)
{
    avl_node *temp;
    temp = parent->right;
    parent->right = ll_rotation (temp);
    return rr_rotation (parent);
}

/*
 * Balancing AVL Tree
 */
avl_node *avlTree::balance(avl_node *temp)
{
    int bal_factor = diff (temp);
    if (bal_factor > 1)
    {
        if (diff (temp->left) > 0)
            temp = ll_rotation (temp);
        else
            temp = lr_rotation (temp);
    }
    else if (bal_factor < -1)
    {
        if (diff (temp->right) > 0)
            temp = rl_rotation (temp);
        else
            temp = rr_rotation (temp);
    }
    return temp;
}

avl_node *avlTree::insert(avl_node* root, int value)
{
    if (root == NULL)
    {
        root = new avl_node;
        root->data = value;
        root->left = NULL;
        root->right = NULL;
        return root;
    }
    else if (value < root->data)
    {
        root->left = insert(root->left, value);
        root = balance (root);
    }
    else if (value >= root->data)
    {
        root->right = insert(root->right, value);
        root = balance (root);
    }
    return root;
}

void avlTree::display(avl_node *ptr, int level)             //this display approx. in the tree form of level order
{
    int i;
    if (ptr!=NULL)
    {
        display(ptr->right, level + 1);
        printf("\n");
        if (ptr == root_1 || ptr==root_2)
            cout<<"Root -> ";
        for (i = 0; i < level && ptr != root_1 && ptr!=root_2; i++)

            cout<<"        ";
        cout<<ptr->data;
        display(ptr->left, level + 1);
    }
}





