#include<stdio.h>
#include<iostream>

using namespace std;

struct tree_node
{
    int data;
    struct tree_node *left;
    struct tree_node *right;
    struct tree_node *parent;

};


struct tree_node* root=NULL;

void insert_node(int d)
{
    struct tree_node* temp = (struct tree_node*) malloc(sizeof(struct tree_node));
    if(root==NULL)
    {
        temp->data=d;
        temp->right=NULL;
        temp->left=NULL;
        temp->parent=NULL;
        root=temp;
    }
    else
    {
        tree_node* p=root;
        tree_node* t=NULL;
        while(p!=NULL)
        {
            t=p;
            if(d>=p->data)
            {
                p=p->right;
            }
            else
            {
                p=p->left;
            }
        }
        temp->data=d;
        temp->right=NULL;
        temp->left=NULL;
        if(d>=t->data)
            {
                t->right=temp;
            }
            else
            {

                t->left=temp;
            }
        temp->parent=t;

    }

}

tree_node *search_node(int d)
{
        tree_node *temp=root;
        while(temp!=NULL)
        {

            if(temp->data==d)
            {

                return temp;
            }
            else{
            if(d>temp->data)
            {

                temp=temp->right;
            }
            else
            {
                temp=temp->left;
            }}
        }
        cout<<"NOT FOUND!!";
        return NULL;
}

tree_node *minimum(tree_node *x) {
    if(x->right!=NULL)
    {
        x=x->right;
        while(x->left != NULL)
        {x = x->left;}
        return x;
    }
    else if(x->left!=NULL){
            x=x->left;
        while(x->right != NULL)
        {x = x->right;}
        return x;
    }
    else{return x;}
}

void transplant(tree_node *u,tree_node*v)
{
    if(u->parent==NULL)
    {
        root=v;
    }
    else if(u==u->parent->left)
    {
      u->parent->left=v;
    }
    else
    {
     u->parent->right=v;

    }
    v->parent = u->parent;

}

void delete_node(int d)
{
    tree_node *z=search_node(d);

   if(z->left == NULL) {
    transplant(z, z->right);
   free(z);
  }
  else if(z->right == NULL) {
    transplant(z, z->left);
   free(z);
  }
  else {
    tree_node *y = minimum(z); //minimum element in right subtree
    if(y->parent != z) {
            if(y->right!=NULL){
      transplant( y, y->right);}
      y->right = z->right;
      y->right->parent = y;
    }
    transplant(z, y);
    y->left = z->left;
    y->left->parent = y;
   free(z);
  }
}

void inorder(tree_node *t)
{
    if(t==NULL){return;}
   inorder(t->left);
   cout<<t->data<<", ";
   inorder(t->right);

}
void preorder(tree_node *t)
{
    if(t==NULL){return;}
    cout<<t->data<<", ";
   inorder(t->left);

   inorder(t->right);

}

void postorder(tree_node *t)
{
   if(t==NULL){return;}
   inorder(t->left);
   inorder(t->right);
   cout<<t->data<<", ";
}
int main()
{
    insert_node(100);
    insert_node(50);
    insert_node(150);
    insert_node(45);
    insert_node(200);
    insert_node(90);
    insert_node(60);
    insert_node(99);
    delete_node(50);
    inorder(root);
    tree_node* test=search_node(150);
    cout<<test->data;
    return 0;
}
