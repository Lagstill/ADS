/*************************************************************
            ADVANCE DATA STRUCTURE LAB
                    18XD34
            PSG COLLEGE OF TECHNOLOGY
                     AMCS
                  PROBLEM_1
                   19PD05
28/09/2020    III SEMESTER ADS_LAB
****************************************************************/

#include<iostream>
#include<string>
#include<bits/stdc++.h>
#include<stdio.h>

using namespace std;

struct tree_node                                                                //creating each node in the tree
{
    int counter;
    string word;
    tree_node *left_child;
    tree_node *right_child;
};

struct tree_node* root=NULL;

tree_node *insert_node(tree_node* root,string data)
{
    struct tree_node* temp = new tree_node;
    transform(data.begin(), data.end(), data.begin(), ::tolower);               //to convert the word into lowercase for comparision
    if(root==NULL)
    {
        temp->word=data;
        temp->right_child=NULL;
        temp->left_child=NULL;
        temp->counter=1;
        root=temp;
    }
    else
    {
        tree_node* p=root;
        tree_node* t=NULL;
        while(p!=NULL)
        {
            t=p;
            if(data==p->word)
            {
                p->counter=p->counter+1;//tracking the number of repeatation of the words
                return root; //break
            }
            if(data>p->word)//check if it would be a left or a right child
            {
                p=p->right_child;
            }
            else
            {
                p=p->left_child;
            }
        }
        temp->word=data;
        temp->right_child=NULL;
        temp->left_child=NULL;
        temp->counter=1;
        if(data>t->word)
        {
            t->right_child=temp;
        }
        else
        {

            t->left_child=temp;
        }
    }
    return root;
}

void Inorder(tree_node* n)//gives the words in ascending order
{
    if (n == NULL)
        return;
    Inorder(n->left_child);
    cout << "Word : "<<n->word<<"\t && \tCount : "<<n->counter<<endl;
    Inorder(n->right_child);
}

int main()
{
    int i,start=0;
    ifstream pt;
    string ch,temp,data;
    string filename="test.txt";
    cout<<"THE CONTENTS IN THE .txt FILE :\n\n";
    pt.open(filename.c_str());  //opens the file in such a way that it is read as strings.
    if(!pt)
    {
        cout<<"No such file exists"<<endl;
    }
    else
    {
        while(pt>>ch)
        {
            cout<<ch<<" ";//printing with spaces "clearance"
        }
    }
    pt.close();

    cout<<"\n\nTHE CONTENTS WRITTEN IN THE FILE HAS BEEN SET INTO A BST AND LISTED BELOW WITH THEIR RESPECTIVE NO. OF OCCURENCE\n\nIN-ORDER TRANSVERSAL\n";
    ifstream readfile(filename); //we are reading the file not editing it
    while(getline(readfile,data))
    {
        data=data+'#';
        for(i=0; i<data.size(); i++)
        {

            if(data[i]== ',' || data[i]==' ' || data[i]=='-' || data[i]=='.')//disregarding these characters
            {
                if(data[i+1]== ',' || data[i+1]=='-')
                    i++;
                else
                {
                    temp=data.substr(start,i-start);//combine the characters until the above characters are encountered and makes it as a string
                    root=insert_node(root,temp);
                    start=i+1;
                }
            }
            if (data[i]=='#')//For me the last word did not appear into account so I append a character-"#" to the last word to make it recognizable
            {
                temp=data.substr(start,i-start);
                root=insert_node(root,temp);
            }
        }
    }
    Inorder(root);//Displaying the tree.
}

