/*************************************************************
            ADVANCE DATA STRUCTURE LAB
                    18XD34
            PSG COLLEGE OF TECHNOLOGY
                     AMCS
              PROBLEM_SHEET_2_[1]
                   19PD05
28/10/2020      III SEMESTER
****************************************************************/
#include <iostream>
using namespace std;

class Node
{
    int *keys;                   //ARRAYS OF KEYS
    int t;                       //MAX NO. OF KEYS-MIN NO.
    Node **C;                    //ARRAYS OF CHILD POINTERS
    int n;                       //TOTAL NO. OF KEYS
    bool leaf;                   //WHETHER IF IT IS A LEAF NODE OR NOT

public:
    Node(int,bool );

    void insertNonFull(int);
    void splitChild(int ,Node *);
    void print();                   //TO DISPLAY THE CONTENT
    Node *member(int );             //TO SEARCH A PARTICULAR KEY

    friend class BT;
};

class BT
{
    Node *root;
    int t;

public:

    BT(int temp)
    {
        root = NULL;
        t = temp;
    }
    void makeEmpty()
    {
        root=NULL;
    }
    void print()
    {
        if (root != NULL)
            root->print();
    }
    Node *member(int k)
    {
        return (root == NULL) ? NULL : root->member(k);
    }

    void insert(int );
};


int main()
{
    int ch=0;
    bool dec=true;
    cout<<"ENTER THE MIN NO. OF KEYS TO BE USED TO BUILT THE B-TREE :"<<endl;
    cin>>ch;
    BT t(ch);
    while(dec)
    {
        cout<<"\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n";
        cout<<"\nENTER ONE OF THE OPTIONS BELOW:"<<endl;
        cout<<"\n 1.INSERT A KEY ";
        cout<<"\n 2.SEARCH FOR A KEY ";
        cout<<"\n 3.CLEAR B-TREE ";
        cout<<"\n 4.DISPLAY B-TREE ";
        cout<<"\n 5.EXIT \n";
        cout<<"\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n";
        cin>>ch;
        switch(ch)
        {
        case 1:
            cout<<"\nENTER THE VALUE OF THE KEY TO BE INSERTED:\t\t";
            cin>>ch;
            if(ch>=0)
            t.insert(ch);
            else
            cout<<"YOU HAVE ENTERED NEGATIVE NO. : TRY AGAIN!!\n";
            break;
        case 2:
            cout<<"\nENTER THE VALUE OF THE KEY TO BE SEARCHED:\t\t";
            cin>>ch;
            if(t.member(ch) != NULL)
            {
                cout<<"THE KEY IS FOUND IN THE B-TREE!!!!\n";
            }
            else
            {
                cout<<"THE KEY IS NOT FOUND IN THE B-TREE!!!!\n";
            }
            break;
        case 3:t.makeEmpty();
                cout<<"NOW THE B-TREE IS 'EMPTY' !!!!\n";
            break;
        case 4:
            cout << "HERE'S THE B-TREE TRAVERSAL : \t\t";
            t.print();
            break;
        case 5:
            exit(1);
            break;
        default:
            cout<<"IT'S OUT OF THE OPTIONS!!!"<<endl;
            break;
        }
    }
    return 0;
}


Node::Node(int d, bool l)
{
    t = d;
    leaf = l;

    keys = new int[2 * t - 1];
    C = new  Node*[2 * t];

    n = 0;
}

void Node::print()
{
    int i;
        for (i = 0; i < n; i++)
    {
        if (leaf == false)
            C[i]->print();
        cout << " " << keys[i];
    }

    if (leaf == false)
        C[i]->print();

}

Node *Node::member(int k)
{
    int i = 0;
    while (i < n && k > keys[i])
        i++;

    if (keys[i] == k)
        return this;

    if (leaf == true)
        return NULL;

    return C[i]->member(k);
}

void BT::insert(int k)
{
    if (root == NULL)
    {
        root = new Node(t, true);
        root->keys[0] = k;
        root->n = 1;
    }
    else
    {
        if (root->n == 2 * t - 1)
        {
            Node *s = new Node(t, false);

            s->C[0] = root;

            s->splitChild(0, root);

            int i = 0;
            if (s->keys[0] < k)
                i++;
            s->C[i]->insertNonFull(k);

            root = s;
        }
        else
            root->insertNonFull(k);
    }
}

void Node::insertNonFull(int k)
{
    int i = n - 1;

    if (leaf == true)
    {
        while (i >= 0 && keys[i] > k)
        {
            keys[i + 1] = keys[i];
            i--;
        }

        keys[i + 1] = k;
        n = n + 1;
    }
    else
    {
        while (i >= 0 && keys[i] > k)
            i--;

        if (C[i + 1]->n == 2 * t - 1)
        {
            splitChild(i + 1, C[i + 1]);

            if (keys[i + 1] < k)
                i++;
        }
        C[i + 1]->insertNonFull(k);
    }
}

void Node::splitChild(int d, Node *y)
{
    Node *temp = new Node(y->t, y->leaf);
    temp->n=t-1;

    for (int i= 0;i< t - 1;i++)
        temp->keys[i] = y->keys[i+t];

    if (y->leaf == false)
    {
        for (int i = 0;i<t;i++)
            temp->C[i] = y->C[i+t];
    }

    y->n = t-1;
    for (int i= n; i>= d+1;i--)
        C[i+1] = C[i];

    C[d+1] =temp;

    for (int i= n - 1;i>=d;i--)
        keys[i+1] = keys[i];

    keys[d] = y->keys[t - 1];
    n ++;
}


